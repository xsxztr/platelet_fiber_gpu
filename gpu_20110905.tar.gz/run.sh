#!/bin/bash
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/cuda/lib/
export CUDA_PROFILE=1
export CUDA_PROFILE_CSV=1
./gpuSEM_LB >& out
