/*
 gpu_SEM_LB.c
 
 Main functions for running simulation.

 Author: Scott Christley <schristley@mac.com>
 
 Copyright (C) 2010 Scott Christley
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met: 1. Redistributions of source code must retain the above
 copyright notice, this list of conditions and the following
 disclaimer.  2. Redistributions in binary form must reproduce the
 above copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided with
 the distribution.  3. The name of the author may not be used to
 endorse or promote products derived from this software without
 specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */


#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
//#include <iostream>
//#include <fstream>
//#include <BioSwarm/MultiScale3DGrid.h>
#include "GPUDefines.h"

#define RAND_NUM ((double)rand() / (double)RAND_MAX )
/// BEGIN: DECLARE LOCAL variables
static RECT_GRID     *lattice_gr = NULL;
/// END: DECLARE LOCAL variables

/// BEGIN: DECLARE GPU KERNELS ///
// The fiber network GPU kernels (functions)
extern void *fiber_allocGPUKernel(void *model, int maxLinks, int maxNodes, float dt, float *hostSEMparameters);
extern void fiber_initGPUKernel(void *gpumodel, void *cpumodel, int);

// The SEM GPU kernels (functions)
extern void *sem_allocGPUKernel(void *model, int maxCells, int maxElements, int ReversalPeriod,  float dt, float *hostSEMparameters);
extern void sem_initGPUKernel(void *model, void *g, int numOfCells, int *numOfElements, int *ClockValue, int *SlimeDir,
                              void *hostX, void *hostY, void *hostZ, void *hostVX, void *hostVY, void *hostVZ,
                              void *hostFX, void *hostFY, void *hostFZ,  void *hostType, void *hostBonds);
//extern void sem_invokeGPUKernel(void *model, void *g, void *hostX, void *hostY, void *hostZ, int timeSteps);
extern void sem_invokeGPUKernel(void *model, void *g, void *hostX, void *hostY, void *hostZ, void *hostVX, void *hostVY, void *hostVZ,
                                void *hostFX, void *hostFY, void *hostFZ, int timeSteps, int *ClockValue, int *SlimeDir, int );

extern void skin_invokeGPUKernel(void *model, void *g, void *hostX, void *hostY, void *hostZ,
                                 void *, void *, void *, void *, void *, int timeSteps);
extern void sem_copyGPUKernel(void *model, void *g, void *hostX, void *hostY, void *hostZ, void *hostVX, void *hostVY, void *hostVZ,
                              void *hostFX, void *hostFY, void *hostFZ, int timeSteps, int *ClockValue, int *SlimeDir);

extern void sem_releaseGPUKernel(void *model, void *g);

// GPU Kernels for LB_fluid
void    *fluid_allocGPUKernel(void *model, float dt, float dx, int width, int height, int depth);
void    fluid_initGPUKernel(void *model, void *g, int aFlag, float *hostLBparameters, void **fIN, void **fOUT, void *ux,
                         void *uy, void *uz, void *rho, void *obstacle);
void    fluid_invokeGPUKernel(void *model, void *g, int timeSteps);
void    fluid_releaseGPUKernel(void *model, void *g);
/// END: DECLARE GPU KERNELS ///

/// Local function 
static void  runGPUSimulation(void);
static void  outputSave(int t, int nx, int ny, int nz, void *rho, int write_rho,
               void *ux, void *uy, void *uz, int write_vel, char *directory, char *filename);
static void  writeVTK(int t, int nx, int ny, int nz,
               void *rho, int write_rho, void *ux, void *uy, void *uz, int write_vel, char *directory, char *filename);
static RECT_GRID *init_lattice_grid(int,int,int,float);
/// END: Local function 

//float hostParameters[100];

// spatial domain
// For 128 and 250 cells
#define BOUNDARY_X 100.0
#define BOUNDARY_Y 100.0

#define BOUNDARY_Z 10.0
#define Z_RANGE 0.5
#define Z_OFFSET 0.5

#define INTER_DIST 0.6

// species index
#define NOTCH_species 0
#define DELTA_species 1
#define BOUND_species 2
#define BMA_species 3
#define OVOL1_species 4
#define OVOL2_species 5
#define CMYC_species 6

#define Cell_Width 0.5
#define Cell_Length 5.0 


// Generate normally distributed random number
double normal_dist_rand(double mean, double sd)
{
  double fac, radius, v1, v2;
  double rd1Value, rd2Value;

  do {
    rd1Value = RAND_NUM;
    rd2Value = RAND_NUM;
    v1 = (2.0 * rd1Value) - 1.0;
    v2 = (2.0 * rd2Value) - 1.0;
    radius = v1*v1 + v2*v2; 
  } while (radius >= 1.0);
  fac = sqrt (-2.0 * log (radius) / radius);
  return v2 * fac * sd + mean;    // use fixed params
}

// Readers for input
//
// This Parser looks for the parameter file specified by the Path ParName.
// The format of the parameter file should be as follows
//
// <KEYWORD>   value
// <KEYWORD>   value



void ParReader( char ParName[], float *pdt ,float *psimTime , int *pOutputFreq, int *pMaxCells, 
              int *pMaxElements, char *pPDBName, char *pPSFName, int *pRevPer, float *HostParam )
{


    FILE *parIn;
    parIn = fopen(ParName , "r");
    int notDone = 1;

    if (parIn == NULL)
       {
          printf("Parameter File was not open");
          exit(1);
       }
  char PDBFileName[25];
  char PSFFileName[25];
  char KEYWORD[20];
//  char CmpKey[18][20] = {"PDB_PATH","DELTA_t","SIM_TIME","OUT_FREQ","MAX_CELL","MAX_ELEM","REV_PER","CELL_WIDTH","CELL_LENGTH","K_BOND","THETA_EQ","K_THETA","MASS_PER_ELEM","GAMMA"
//                          , "SLIME_FORCE", "LJ_EPS", "NB_CUTOFF", "TEMP" };
  float *p2dt = malloc(sizeof(float));
  int OutFreq, MaxCells, MaxElems,  revPer;
  float SimTime;
/////Read in Path to PDB
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "PDB_PATH") ){
       fscanf(parIn, "%s"  , pPDBName);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "PDB_PATH");
         exit(1);
       }
/////Read in Path to PSF
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "PSF_PATH") ){
       fscanf(parIn, "%s"  , pPSFName);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "PSF_PATH");
         exit(1);
       }


///Read in dt
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "DELTA_T") ){
       fscanf(parIn, "%f" , p2dt);
       *pdt = *p2dt;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "DELTA_T");
         exit(1);
       }
  
///Read in Simulation time (total in units of time:  eg.  200 -> is 200 us, if dt = .1, this will need 2000 simulation Steps)
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "SIM_TIME") ){
        fscanf(parIn, "%f", &SimTime);
        *psimTime = SimTime;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "SIM_TIME");
         exit(1);
       }

///Read in Output Frequency in simulation Steps. Eg if SIM_TIME=200, dt=.01, (TotalSimSteps=20000),
/// outputFreq=200 -> gives 100 frames (outputs)
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "OUT_FREQ") ){
       fscanf(parIn, "%d", &OutFreq);
       *pOutputFreq = OutFreq;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "OUT_FREQ");
         exit(1);
       }
// Read In Max cells
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "MAX_CELL") ){

       fscanf(parIn, "%d", &MaxCells);
       *pMaxCells = MaxCells;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "MAX_CELL");
         exit(1);
       }
// Read In number of SCE per cell
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "MAX_ELEM") ){
       fscanf(parIn, "%d", &MaxElems);
       *pMaxElements = MaxElems;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "MAX_ELEM");
         exit(1);
       }
// Read In Reversal Period in Simulations Steps (Rev_PER * dt = Rev_Per in unit sim time)
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "REV_PER") ){
       fscanf(parIn, "%d", &revPer);
       *pRevPer = revPer;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "REV_PER");
         exit(1);
       }
// NOW WE FILL IN THE HOSTPARAMETER array which contains parameters for force calculations
// Read In cell width
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "CELL_WIDTH") ){
       fscanf(parIn, "%f", & HostParam[0]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "CELL_WIDTH");
         exit(1);
       }
// Read In cell length
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "CELL_LENGTH") ){
       fscanf(parIn, "%f", &HostParam[1]);
       // Use cell_length and Num SCE to caluclate segment length
       HostParam[2] = HostParam[1] / MaxElems;
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "CELL_LENGTH");
         exit(1);
       }
// Read In bonding coefficient (k_bond)
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "K_BOND") ){
       fscanf(parIn, "%f", &HostParam[3]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "K_BOND");
         exit(1);
       }
// Read In target (equilibrium angle)
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "THETA_EQ") ){
       fscanf(parIn, "%f",& HostParam[4]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "THETA_EQ");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "K_THETA") ){
       fscanf(parIn, "%f", &HostParam[5]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "K_THETA");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "MASS_PER_ELEM") ){
       fscanf(parIn, "%f", &HostParam[6]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "MASS_PER_ELEM");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "GAMMA") ){
       fscanf(parIn, "%f", &HostParam[7]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "GAMMA");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "SLIME_FORCE") ){
       fscanf(parIn, "%f", &HostParam[8]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "SLIME_FORCE");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "LJ_EPS") ){
       fscanf(parIn, "%f", &HostParam[9]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "LJ_EPS");
         exit(1);
       }
// Read In 
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "NB_CUTOFF") ){
       fscanf(parIn, "%f", &HostParam[10]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "NB_CUTOFF");
         exit(1);
       }
// Read In  "Temperature", where TEMP = k_b * T:  this is given in untis fJ k^-1,  take T = 300k, k_b = 1.3806504(24)x10^-23 (J k^-1)
//  TEMP = 300 * 1.38 * 10^-23 * 10^6 (um conv) * 10^9 (nN conv) = 4.14e-6
  fscanf(parIn, "%s"  , KEYWORD);
    if (!strcmp(KEYWORD, "TEMP") ){
       fscanf(parIn, "%f", &HostParam[11]);
       }
      else
       {
         printf("Parameter Read Failed for %s \n", "TEMP");
         exit(1);
       }

}


void PDBReader(char * PDBFileP, int NumCells, int NumSCE,  float *X, float *Y, float *Z, int *elemType){
    FILE *pdbIn;
    char  PDBFilename[512];   
  //        printf("Reader Called \n");
    strcpy(PDBFilename , PDBFileP);
    pdbIn = fopen(PDBFileP , "r");
    if (pdbIn == NULL)
       {
          printf("File was not open");
          exit(1);
       }
  char type [5], SCE_type [4] , residue [4], trash [2], trash2 [5];
  int  index, cell_ID, ElemInCell;
  float iX, iY, iZ, t1, t2 ;
  int more = 1, Values = 0;
  while( more){
  fscanf(pdbIn, "%s"  , type);
    if (strcmp(type, "ATOM") ){
        //  printf("Stopped after %d calls \n", Values);
       more = 0;
       break;
       }
      fscanf(pdbIn, "%d" , &index);
      fscanf(pdbIn, "%s"  , SCE_type);
      fscanf(pdbIn, "%s"  , residue);
      fscanf(pdbIn, "%s"  , trash);
      fscanf(pdbIn, "%d" , &cell_ID);
      fscanf(pdbIn, "%f" , &iX);
      fscanf(pdbIn, "%f" , &iY);
      fscanf(pdbIn, "%f" , &iZ);
      fscanf(pdbIn, "%f" , &t1);
      fscanf(pdbIn, "%f" , &t2);
      fscanf(pdbIn, "%s"  , trash2);
      ElemInCell = index % NumSCE;
       if (!ElemInCell) ElemInCell = NumSCE; // if modulo == 0, then set ElemInCell to 10
      ElemInCell--; // decrement by 1 for index
      cell_ID--;
      *(X + cell_ID + NumCells * ElemInCell )=iX;
      *(Y + cell_ID + NumCells * ElemInCell )=iY;
      *(Z + cell_ID + NumCells * ElemInCell )=iZ;
      // assign element type to elementType array
      if (!strcmp(SCE_type, "CA"))
       *(elemType + cell_ID + NumCells * ElemInCell )= 1;
       else if (!strcmp(SCE_type, "C1"))
        *(elemType + cell_ID + NumCells * ElemInCell )= 2;
       else if (!strcmp(SCE_type, "C2"))
        *(elemType + cell_ID + NumCells * ElemInCell )= 3;
       else if (!strcmp(SCE_type, "C3"))
        *(elemType + cell_ID + NumCells * ElemInCell )= 5;
       else if (!strcmp(SCE_type, "C4"))
        *(elemType + cell_ID + NumCells * ElemInCell )= 7;
      else
       {
         printf("Failed to assigne Element type  %s \n", SCE_type);
         exit(1);
       }
         
   /*   printf ("Values is %d  \n", Values);
      printf ("type = %s \n ", type );
      printf ("SCE_type = %s \n ", SCE_type );
      printf ("resdiue = %s \n ", residue );
      printf ("trash = %s \n ", trash );
      printf ("Cell_ID = %d \n ", cell_ID );
     printf ("Index = %d \n ", index );
     printf ("ElemIn Cell = %d  and cell_ID = %d \n ", ElemInCell, cell_ID  );
      printf ("iX = %f \n ", *(X + cell_ID + NumCells * ElemInCell) );
      printf ("iY = %f \n ", *(Y + cell_ID + NumCells * ElemInCell) );
      printf ("iZ = %f \n ", *(Z + cell_ID + NumCells * ElemInCell) );
    printf ("t1 = %f \n ", t1 );
      printf ("t2 = %f \n ", t2 );
      printf ("trash2 = %s \n ", trash2 );
  */  Values++; //THis is for debuging purposes only     
    }
  }
/*

CA = 1
C1 = 2
C2 = 3
C3 = 5
c4 = 7

CA  C1   10.000     1.0 !
CA  C2   10.000     0.609805419065 !
CA  C3   10.000     0.325371911561 !
CA  C4   10.000     0.25 !
C1  C1   10.000     0.61803398875 !
C2  C2   10.000     0.376880475506 !
C3  C3   10.000     0.201090900329 !
C1  C2   10.000     0.501200956307 !
C2  C3   10.000     0.319042712706 !
C3  C4   10.000     0.325656161 !
*/
void PSFReader(char * PSFFileP, int NumCells, int NumSCE,  float *bondValue, int *elemType){
    FILE *psfIn;
    char  PSFFilename[512], checkForm[512], type [512];   
  //        printf("Reader Called \n");
// this is the bondLength array defined...TODO, add to input parameterfile OR newly formatted PSF
    float *bondLength = malloc(50*sizeof(float));
    bondLength[2] = 1.0;//CA C1
    bondLength[3] =  0.6098054 ; // CA C2
    bondLength[4] =  0.6180340 ;//  C1 C1
    bondLength[5] =  0.3253719 ;//  CA C3
    bondLength[6] =  0.5012001 ;//  C1 C2
    bondLength[7] =  0.25 ;//  CA C4
    bondLength[9] =  0.3768805;//  C2 C2
    bondLength[15] = 0.3190427  ;// C2 C3
    bondLength[25] = 0.2010909  ;// C3 C3
    bondLength[35] = 0.3256562   ;// C3 C4
   // bondlength[43] =   ;//
  //  float bondLengths[50];
    strcpy(PSFFilename , PSFFileP);
    psfIn = fopen(PSFFileP , "r");
    if (psfIn == NULL)
       {
          printf("File was not open");
          exit(1);
       }
  fscanf(psfIn, "%s"  , checkForm);
    if (strcmp(checkForm, "PSF_New") ){
          printf("PSF File Not Formated correctly was");
          exit(1);
    }

  int more = 1, values, numBonds;
  fscanf(psfIn, "%s"  , type);
  if (!strcmp(type, "!NBOND:") ){
     fscanf(psfIn, "%d"  , &numBonds);
       }
  int sce1, sce2, ElemInCell1, ElemInCell2, cell_ID, type1, type2, bondType;
  int i;
  for( i = 0; i < numBonds; i++){
     fscanf(psfIn, "%d"  , &sce1);//sce1 and sce2 are the index of the SCE elements
     fscanf(psfIn, "%d"  , &sce2);//
       ElemInCell1 = sce1 % NumSCE;
         if (!ElemInCell1) ElemInCell1 = NumSCE; // if modulo == 0, then set ElemInCell to last
       ElemInCell1--; // decrement by 1 for index
       cell_ID = floor(ElemInCell1 / NumSCE);
       type1 =  *(elemType + cell_ID + NumCells * ElemInCell1 );
       ElemInCell2 = sce2 % NumSCE;
         if (!ElemInCell2) ElemInCell2 = NumSCE; // if modulo == 0, then set ElemInCell to 10
       ElemInCell2--; // decrement by 1 for index
       cell_ID = floor(ElemInCell2 / NumSCE);
       type2 =  *(elemType + cell_ID + NumCells * ElemInCell2 );
     bondType = type1 * type2;
    // make this matrix symetric for good measure
    *(bondValue + ElemInCell1 + NumSCE * ElemInCell2 )= bondLength[bondType];
    *(bondValue + ElemInCell2 + NumSCE * ElemInCell1 )= bondLength[bondType];
     
  } 

}

static RECT_GRID *init_lattice_grid(
	int      lx,
        int      ly,
        int      lz,
        float    dx)
{
        int      i, dim = 3;
        RECT_GRID  *gr;

        gr = (RECT_GRID*) malloc(sizeof(RECT_GRID));
        gr->gmax[0] = lx;
        gr->gmax[1] = ly;
        gr->gmax[2] = lz;
        gr->dim = 3;

        for(i = 0; i < dim; i++)
        {
            gr->lL[i] = 0.0;
            gr->lU[i] = dx*(gr->gmax[i]-1);
            gr->h[i] = dx;
            gr->lbuf[i] = gr->ubuf[i] = 0;
        }

        return gr;
}

static void runGPUSimulation()
{
  int    i, j;
  int    p, l, k, d;
  float  cu;
  int    *pMaxCells = malloc(sizeof(int));
  int    *pMaxElements = malloc(sizeof(int));
  float  *pSimulateTime = malloc(sizeof(float));
  int    *pOutputFreq = malloc(sizeof(int));
  int    *pRevPer = malloc(sizeof(int));
  float  *pDt = malloc(sizeof(float));
 
  float  *hostSEMparameters = (float *)malloc( 100 * sizeof(float));
  float  *hostLBparameters = malloc(sizeof(float) * 100);

  int    maxCells , numOfCells, maxElements , InitialElements, ReversalPeriod;
  char   *pPDBName = malloc( 25 * sizeof(char));
  pPDBName[0] = 'C';
  pPDBName[1] = '\0';
  char *pPSFName = malloc( 25 * sizeof(char));
  pPSFName[0] = 'C';
  pPSFName[1] = '\0';
  char PDBName[25];
  char ParName[] = "Input/parameter.dat";

  // execution settings
  float dt, simulateTime;
  int outputFrequency,  thisFrame;


  /// Reader Parameter FILE and intialize Readers for PDB and PSF ///  
  ParReader( ParName , pDt, pSimulateTime, pOutputFreq,  pMaxCells, pMaxElements,  pPDBName, pPSFName,
                 pRevPer, hostSEMparameters);
  // Assign values from parameter read in to variables 
  maxCells = *pMaxCells;
  maxElements = *pMaxElements;
  numOfCells = maxCells;
  InitialElements = maxElements;
  dt = *pDt;
  outputFrequency = *pOutputFreq;
  simulateTime = *pSimulateTime;
  ReversalPeriod = *pRevPer; // This is how long a reversal period is in simulation steps


  int timeSteps =  simulateTime / dt; //Assigns number of simulations steps from input parameters

  /// BEGIN: HOST MEMORY ALLOCOATION ///

  /// HOST ALLOCATION FOR SEM ///
  // initialize cell position, velocity, force memory locations, as well as clock's and slime direction
  int *numOfElements = (int *)malloc(maxCells * sizeof(int));
  int *ClockValue = (int *)malloc(maxCells * sizeof(int));// added to give each cell's it own clock
  int *SlimeDir = (int *)malloc(maxCells * sizeof(int));// added to give each cell's it own slimeDir

  void *elementType = malloc(maxCells * maxElements * sizeof(int));
  int (*etGrid)[maxElements][maxCells] = elementType;
  void *bondLengths = malloc(maxElements * maxElements * sizeof(int));
 // int totElem = maxCells * maxElements;
  float (*bondgrid)[maxElements][maxElements] = bondLengths;

  void *X = malloc(maxCells * maxElements * sizeof(float));
  void *Y = malloc(maxCells * maxElements * sizeof(float));
  void *Z = malloc(maxCells * maxElements * sizeof(float));
  float (*xGrid)[maxElements][maxCells] = X;
  float (*yGrid)[maxElements][maxCells] = Y;
  float (*zGrid)[maxElements][maxCells] = Z;
//   float (*xGrid)[maxElements][maxCells] = (float (*)[maxElements][maxCells])X;
//   float (*yGrid)[maxElements][maxCells] = (float (*)[maxElements][maxCells])Y;
//   float (*zGrid)[maxElements][maxCells] = (float (*)[maxElements][maxCells])Z;
// add force and velocity arrays
  void *VX = malloc(maxCells * maxElements * sizeof(float));
  void *VY = malloc(maxCells * maxElements * sizeof(float));
  void *VZ = malloc(maxCells * maxElements * sizeof(float));
  float (*xVGrid)[maxElements][maxCells] = VX;
  float (*yVGrid)[maxElements][maxCells] = VY;
  float (*zVGrid)[maxElements][maxCells] = VZ;

  void *FX = malloc(maxCells * maxElements * sizeof(float));
  void *FY = malloc(maxCells * maxElements * sizeof(float));
  void *FZ = malloc(maxCells * maxElements * sizeof(float));
  float (*xFGrid)[maxElements][maxCells] = FX;
  float (*yFGrid)[maxElements][maxCells] = FY;
  float (*zFGrid)[maxElements][maxCells] = FZ;

  float *centerX = (float *)malloc(maxCells * sizeof(float));
  float *centerY = (float *)malloc(maxCells * sizeof(float));
  float *centerZ = (float *)malloc(maxCells * sizeof(float));

  void *numNeighbors = malloc(maxCells * maxElements * sizeof(int));
  int (*nnGrid)[maxElements][maxCells] = numNeighbors;


  /// HOST ALLOCATION FOR LB ///
  // create spatial grids. 
  /*** original for fluid-SCE cell simulation
  int lx = 50;       /// width, original = 25,
  int ly = 50;       /// height, original = 25
  int lz = 400;     /// depth, original = 1000
  float dx = 1.0;    /// LB lattice spacing. = 1micron
  ***/
  int lx = 200;       /// width, original = 25,
  int ly = 40;       /// height, original = 25
  int lz = 200;     /// depth, original = 1000
  float dx = 2.0;    /// LB lattice spacing. = 1micron

  if(NULL == lattice_gr)
  {
      lattice_gr = init_lattice_grid(lx,ly,lz,dx);
  } 

  printf("Simulation domain X[%f, %f], Y[%f, %f], Z[%f, %f], dx = %f\n", 
           0.0, lx*dx, 0.0, ly*dx, 0.0, lz*dx, dx);

  void *fIN[19];
  void *fOUT[19];

  for (i = 0; i < 19; ++i) {
   fIN[i]  = malloc(lx * ly * lz * sizeof(float));
   fOUT[i] = malloc(lx * ly * lz * sizeof(float)); 
  }
  void *ux = malloc(lx * ly * lz * sizeof(float));
  void *uy = malloc(lx * ly * lz * sizeof(float));
  void *uz = malloc(lx * ly * lz * sizeof(float));
  void *rho = malloc(lx * ly * lz * sizeof(float));
  void *obstacle = malloc(lx * ly * lz * sizeof(float));

  float (*gridX)[lz][ly][lx] = ux;
  float (*gridY)[lz][ly][lx] = uy;
  float (*gridZ)[lz][ly][lx] = uz;
  float (*gridR)[lz][ly][lx] = rho;
  float (*gridO)[lz][ly][lx] = obstacle;

  float (*gridIN)[lz][ly][lx];
  float (*gridOUT)[lz][ly][lx];

  /// BEGIN: INITIALIZATION OF VALUES ///

  /// LB : INIT  ///
  float f0[] = {1.0/3.0, 1.0/18.0, 1.0/18.0, 1.0/18.0, 1.0/18.0, 1.0/18.0, 1.0/18.0,
                1.0/36.0, 1.0/36.0, 1.0/36.0, 1.0/36.0,
                1.0/36.0, 1.0/36.0, 1.0/36.0, 1.0/36.0,
                1.0/36.0, 1.0/36.0, 1.0/36.0, 1.0/36.0};
  float cx[] = {0, 1, 0, 0, -1,  0,  0,  1, -1, -1,  1, 1, -1, -1,  1, 0,  0,  0,  0};
  float cy[] = {0, 0, 1, 0,  0, -1,  0,  1,  1, -1, -1, 0,  0,  0,  0, 1, -1, -1,  1};
  float cz[] = {0, 0, 0, 1,  0,  0, -1,  0,  0,  0,  0, 1,  1, -1, -1, 1,  1, -1, -1};

  // % INITIAL CONDITION: Poiseuille profile at equilibrium
  // obstacle
  //  INIT. Walls of Flow Channel
  for (i = 0; i < lz; ++i)
    for (j = 0; j < ly; ++j)
      for (k = 0; k < lx; ++k)
      {
          (*gridO)[i][j][k] = 0.0;
      }

  for (i = 0; i < lz; ++i) 
  {
    for (j = 0; j < lx; ++j) 
    {
      (*gridO)[i][0][j] = 1.0;
      (*gridO)[i][ly-1][j] = 1.0;
    }
    for (j = 0; j < ly; ++j) {
      (*gridO)[i][j][0] = 1.0;
      (*gridO)[i][j][lx-1] = 1.0;
    }
  }
  // END::: INIT. Walls of Flow Channel

  /// init flow.
  float LY = ly - 2.0;
  float LX = lx - 2.0;
  float UMAX = 0.4;   /// maximum velocity of Poiseuille inflow = fluid_parameters[1] = 0.4 miron/millisec = 0.4 mm/sec.
  float INIT_RHO = 1.0; /// picogram/micron^3
  for (i = 0; i < lz; ++i)
    for (j = 0; j < ly; ++j)
      for (k = 0; k < lx; ++k) 
      {
        float y_phys = j - 0.5;
        float x_phys = k - 0.5;

        if((*gridO)[i][j][k] > 0.5) 
        { /// WALL
            (*gridX)[i][j][k] = 0.0;
            (*gridY)[i][j][k] = 0.0;
            (*gridZ)[i][j][k] = 0.0;
            (*gridR)[i][j][k] = 0.0; /// picogram/micron^3
        }
        else
        {
            (*gridX)[i][j][k] = 0.0;
            (*gridY)[i][j][k] = 0.0;
            (*gridZ)[i][j][k] = 16.0 * UMAX / (LY * LY * LX * LX) * (y_phys * LY - y_phys * y_phys) * (x_phys * LX - x_phys * x_phys);
            // (*gridZ)[i][j][k] = UMAX;
            (*gridR)[i][j][k] = INIT_RHO; /// picogram/micron^3
        }
      }

  /***
  /// TMP, output initial data.
  {
        FILE *tmp_fp[3];
        tmp_fp[0] = fopen("Output/initcenter_line_ux.dat", "wb+");
        tmp_fp[1] = fopen("Output/initcenter_line_uy.dat", "wb+");
        tmp_fp[2] = fopen("Output/initcenter_line_uz.dat", "wb+");
        for (i = 0; i < lz ; ++i)
        {
            fprintf(tmp_fp[0],"%f\n", (*gridX)[i][ly/2][lx/2]);
            fprintf(tmp_fp[1],"%f\n", (*gridY)[i][ly/2][lx/2]);
            fprintf(tmp_fp[2],"[%d][0][10]=%f, [%d][1][10]=%f\n", 0, (*gridZ)[i][0][lx/2], 1, (*gridZ)[i][1][lx/2]);
        }
        fclose(tmp_fp[0]);
        fclose(tmp_fp[1]);
        fclose(tmp_fp[2]);
        // exit(0);
  }
  ///END::: TMP, output initial data.
  ***/

  ////// set the discrete velocity vectors.
  for (d = 0; d < 19; ++d) {
      cx[d] *= dx/dt;
      cy[d] *= dx/dt;
      cz[d] *= dx/dt;
  }
  ///// init. density distribution function
  for (d = 0; d < 19; ++d) {
    gridIN = (void *)fIN[d];
    gridOUT = (void *)fOUT[d];
    for (i = 0; i < lz; ++i)
      for (j = 0; j < ly; ++j)
        for (k = 0; k < lx; ++k) {
          cu = 3.0 * (cx[d] * (*gridX)[i][j][k] + cy[d] * (*gridY)[i][j][k] + cz[d] * (*gridZ)[i][j][k]);
          /*** Original, scott's implementation. Assumed C = 1.
          (*gridIN)[i][j][k] = (*gridR)[i][j][k] * f0[d] * (1.0 + cu + 0.5 * cu * cu - 
                               1.5 * ((*gridX)[i][j][k] * (*gridX)[i][j][k] + 
                                      (*gridY)[i][j][k] * (*gridY)[i][j][k] + (*gridZ)[i][j][k] * (*gridZ)[i][j][k]));
          ****/ 
          (*gridIN)[i][j][k] =  (*gridR)[i][j][k] * f0[d] * ( 1.0 + cu/sqr(dx/dt) + 0.5*cu*cu/quar(dx/dt) -
                                  1.5* ((*gridX)[i][j][k] * (*gridX)[i][j][k] + 
                                      (*gridY)[i][j][k] * (*gridY)[i][j][k] + (*gridZ)[i][j][k] * (*gridZ)[i][j][k])/sqr(dx/dt));
          (*gridOUT)[i][j][k] = 0.0;
      }
  }
  // obst_r = ly/10+1;  % radius of the cylinder
  hostLBparameters[0] = ly / 10.0 + 1;
  // maximum velocity of Poiseuille inflow
  hostLBparameters[1] = UMAX;
  // vertical lid velocity 
  hostLBparameters[2] = 0.0;
  // Reynolds number
  hostLBparameters[3] = 100.0;
  // kinematic viscosity 
  // hostLBparameters[4] = ((hostLBparameters[1] * 2.0 * hostLBparameters[0]) / hostLBparameters[3]);
  hostLBparameters[4] = 1000.0;   //// water = 1000 micron^2/milli-sec
  // relaxation parameter  should > 0.5
  // hostLBparameters[5] = (1.0 / (3.0 * hostLBparameters[4] + 0.5));
  hostLBparameters[5] = ((3.0 * hostLBparameters[4]*dt)/(dx*dx)) + 0.5;
  // hostLBparameters[5] = 2.5;
  /// dt = (tau - 0.5)*dx^2/(3*mu); 
  /// Ma = v_max/C << 1; where C = dx/dt;
  /// dt < 0.25 to keep Ma < 0.1
  hostLBparameters[6] = INIT_RHO;

  printf("kinematic viscosity = %e, relaxation parameter = %e\n", hostLBparameters[4], hostLBparameters[5]);
  printf("dx/dt = %f, Ma = %f\n", dx/dt, UMAX/(dx/dt));
  // exit(0);

  // obstacle
  //  Walls of Flow Channel
  /*  Moved to the front of init flow.
  for (i = 0; i < lz; ++i) { 
    for (j = 0; j < lx; ++j) {
      (*gridO)[i][0][j] = 1.0;
      (*gridO)[i][ly-1][j] = 1.0;
    }
    for (j = 0; j < ly; ++j) {
      (*gridO)[i][j][0] = 1.0;
      (*gridO)[i][j][lx-1] = 1.0;
    }
  }
  */
 //  Fixed obstacles inside flow
#if 0
  // block obstacle
  for (i = 50; i < 100; ++i)
    for (j = 15; j < 25; ++j)
      for (k = 40; k < 60; ++k)
        (*gridO)[i][j][k] = 1.0;
  for (i = 150; i < 175; ++i)
    for (j = 20; j < 35; ++j)
      for (k = 40; k < 60; ++k)
        (*gridO)[i][j][k] = 1.0;
#endif

#if 0
  // sphere obstacle
  float obst_x = lx / 2.0 + 1.0;
  float obst_y = ly / 2.0 + 3.0;
  float obst_z = lz / 5.0 + 3.0;
  float obst_r = ly / 10.0 + 1.0;
  for (i = 0; i < lz; ++i)
    for (j = 0; j < ly; ++j)
      for (k = 0; k < lx; ++k) {
        float p = (k - obst_x)*(k - obst_x) + (j - obst_y)*(j - obst_y) + (i - obst_z)*(i - obst_z);
        if (p <= obst_r*obst_r)
          (*gridO)[i][j][k] = 1.0;
      }
#endif
#if 0
  // obstacle
  //
  for (i = 0; i < lz; ++i) {
    for (j = 0; j < lx; ++j) {
      (*gridO)[i][0][j] = 1.0;
      (*gridO)[i][ly-1][j] = 1.0;
    }
    for (j = 0; j < ly; ++j) {
      (*gridO)[i][j][0] = 1.0;
      (*gridO)[i][j][lx-1] = 1.0;
    }
  }
#endif

  //////// INIT Fibrin Network Data //////////////////////
  tmp_fiber_GPUgrids *fiber_grids = (tmp_fiber_GPUgrids *)init_fibrin_network(dt);
  cpu_init_fiber_LB(fiber_grids, hostLBparameters, fIN, fOUT, ux, uy, uz, rho, obstacle, lattice_gr, dt);
  fiber_LB_Fsi_force(fiber_grids, hostLBparameters, fIN, fOUT, ux, uy, uz, rho, obstacle, lattice_gr, dt);

  void *gpu_fiber_grids = fiber_allocGPUKernel(NULL, fiber_grids->maxLinks,
                             fiber_grids->maxNodes, dt, NULL);
  fiber_initGPUKernel(gpu_fiber_grids, fiber_grids, 1);
  printf("exit in runGPUSimulation(), after cpu_init_fiber_LB_coupling()\n");
  exit(0);
  // printf("exit in runGPUSimulation(), after init_fibrin_network()\n");
  // exit(0);
  //////// END:::::INIT Fibrin Network Data //////////////


  /// SEM : INIT ///

  // Initialize the ClockValue to some value within the reversal Period
  for (j = 0; j < numOfCells; ++j) {
  double rd1Value = RAND_NUM * (double)ReversalPeriod;
  double rd2Value = RAND_NUM;
 
  if (rd2Value < 0.5)
	SlimeDir[j] = 1;
  else
	SlimeDir[j] = 0;

  ClockValue[j] = (int)rd1Value; // each cell's clock value is initialized to some value between (0, ReversalPeriod) 

  }

  for (j = 0; j < numOfCells; ++j) {  // debug for clockvalue
    // printf("Cell1 clockValue = %d \n", ClockValue[j]);
  }

  // clear values
  for (j = 0; j < numOfCells; ++j) {
    numOfElements[j] = InitialElements;
    centerX[j] = 0.0;
    centerY[j] = 0.0;
    centerZ[j] = 0.0;
    for (i = 0; i < maxElements; ++i)
      (*etGrid)[i][j] = 0;
      
  }
  for (i = 0; i < maxElements; ++i)  
    for (j = 0; j < maxElements; ++j){
    (*bondgrid)[i][j] = 0;
    }

  // Get initial positions from PDB file

  // Read Configuration Files
#if 1
  PDBReader(pPDBName, numOfCells, maxElements, X, Y, Z,elementType );
#endif

  // Make initial positions 
#if 0  // for uniformGrid centered on (0,0, .25)
int ElemInCell, cellPerRow, cellID;
double headX, headY, headZ, nx, ny, nz;
double xx, yy,zz, cellLength, cellSeg, cellWidth;
double longAxisOffset, shortAxisOffset;
  cellPerRow = 16;
  cellLength = 10;
  cellSeg = (cellLength / maxElements);
  cellWidth = 1;
//position of the first element of system
  xx = ((numOfCells / cellPerRow) / 2) * cellLength;
  yy = (cellPerRow / 2) * cellWidth;
  zz = 0.25;
  longAxisOffset = 1.0 * cellWidth;
  shortAxisOffset = 0.5 * cellWidth;
  for (j = 0; j< numOfCells; ++j){
    cellID = j;
    headX = xx - ( (j/cellPerRow) * (cellLength + longAxisOffset));
    headY = yy - ((j%16) * (cellWidth + shortAxisOffset));
    ElemInCell = 0;
    nx = headX;
    ny = headY;
    // *(X + cellID + numOfCells * ElemInCell ) = (double) nx;
    // *(Y + cellID + numOfCells * ElemInCell ) = (double) ny;
    // *(Z + cellID + numOfCells * ElemInCell ) = (double) zz;
     (*xGrid)[0][j] = (double) nx;
     (*yGrid)[0][j] = (double) ny;
     (*zGrid)[0][j] = (double) zz;
    for (i = 1; i < maxElements; ++i){
    ElemInCell = i;
     nx = nx - cellSeg;
     //*(X + cellID + numOfCells * ElemInCell ) = (double) nx;
     //*(Y + cellID + numOfCells * ElemInCell ) = (double) ny;
     //*(Z + cellID + numOfCells * ElemInCell ) = (double) zz;    
     (*xGrid)[i][j] = (double) nx;
     (*yGrid)[i][j] = (double) ny;
     (*zGrid)[i][j] = (double) zz;
    }


  }
#endif

// Check PDB Reader
 // printf("Reader Done \n");
  PSFReader(pPSFName, numOfCells,  maxElements,  bondLengths, elementType);

  int ii;
  int counter = 1;
#if 0
  for (j = 0; j < numOfCells; ++j) {
  numOfElements[j] = InitialElements;
    for (i = 0; i < numOfElements[j]; ++i) {

   printf("Index =  %d \n", counter);
   printf("X pos is %f \n", (*xGrid)[i][j]);
   printf("Y pos is %f \n", (*yGrid)[i][j]);
   printf("Z pos is %f \n", (*zGrid)[i][j]);

   for (ii = 0; ii < numOfElements[j]; ii++){ 
   printf("bondLength for element %d with element %d is  %f \n", i, ii,  (*bondgrid)[i][ii]);
   }
  counter++;
   }
  }
#endif

/// END : HOST INITIALIZATION ///

/// BEGIN:  DEVICE ALLOCATION and INITIALIZATION  ///

  // ALLOC and init SEM on GPU

  void *SEMgrids = sem_allocGPUKernel(NULL, maxCells, maxElements, ReversalPeriod, dt, hostSEMparameters);
  sem_initGPUKernel(NULL, SEMgrids, numOfCells, numOfElements, ClockValue, SlimeDir, 
                    X, Y, Z, VX, VY, VZ, FX, FY, FZ, elementType, bondLengths);//pass force velocity

  void *LBgrids;
  // LBgrids = fluid_allocGPUKernel(NULL, 1.0, 1.0, lx, ly, lz);
  LBgrids = fluid_allocGPUKernel(NULL, dt, dx, lx, ly, lz);
  fluid_initGPUKernel(NULL, LBgrids, 1, hostLBparameters, fIN, fOUT, ux, uy, uz, rho, obstacle);

/// END:  DEVICE ALLOCATION and INITIALIZATION  ///

/// BEGIN : OUTPUT DATA FILE CREATION ///
  // LB data files
  FILE *uxFile, *uyFile, *uzFile, *rhoFile, *obstFile;
  uxFile = fopen("fluid3d_ux.dat", "wb+");
  uyFile = fopen("fluid3d_uy.dat", "wb+");
  uzFile = fopen("fluid3d_uz.dat", "wb+");
  rhoFile = fopen("fluid3d_rho.dat", "wb+");
  obstFile = fopen("fluid3d_obst.dat", "wb+");

  // SEM data files
  FILE *dataFiles[3];

  dataFiles[0] = fopen("Output/cellsPos.data", "wb+");
  dataFiles[1] = fopen("Output/cellsVel.data", "wb+");
  dataFiles[2] = fopen("Output/cellsForce.data", "wb+");

  // debug file
  FILE *cent_fp[3];
  cent_fp[0] = fopen("Output/center_line_ux.dat", "wb+");
  cent_fp[1] = fopen("Output/center_line_uy.dat", "wb+");
  cent_fp[2] = fopen("Output/center_line_uz.dat", "wb+");

  // WRITE INITIAL DATA LB

#if 0
  FILE *fINFile[19], *fOUTFile[19];
  for (i = 0; i < 19; ++i) {
    NSString *s = [NSString stringWithFormat: @"fluid3d_fIN%d.dat", i];
    fINFile[i] = fopen([s UTF8String], "wb+");
    s = [NSString stringWithFormat: @"fluid3d_fOUT%d.dat", i];
    fOUTFile[i] = fopen([s UTF8String], "wb+");
  }
#endif

  for (i = 0; i < lz ; ++i) {
    for (j = 0; j < ly; ++j) {
      for (k = 0; k < lx; ++k) {
      //  [grid dumpGrid: @"ux" toFile: uxFile];
      //  [grid dumpGrid: @"uy" toFile: uyFile];
      //  [grid dumpGrid: @"uz" toFile: uzFile];
      //  [grid dumpGrid: @"rho" toFile: rhoFile];
      //  [grid dumpGrid: @"obstacle" toFile: obstFile];

      fwrite(&((*gridX)[i][j][k]), sizeof(float), 1, uxFile);
      fwrite(&((*gridY)[i][j][k]), sizeof(float), 1, uyFile);
      fwrite(&((*gridZ)[i][j][k]), sizeof(float), 1, uzFile);
      fwrite(&((*gridR)[i][j][k]), sizeof(float), 1, rhoFile);
      fwrite(&((*gridO)[i][j][k]), sizeof(float), 1, obstFile);
       }
     }
  }
  // WRITE INITIAL DATA SEM
  
  for (j = 0; j < numOfCells; ++j) {
    for (i = 0; i < numOfElements[j]; ++i) {
     //
     // We write an additional z value for the puropse of alignment in the octal dump
     //
     // write initial positions
      fwrite(&((*xGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
      fwrite(&((*yGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
      fwrite(&((*zGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
      fwrite(&((*zGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
     // fwrite(&((*etGrid)[i][j]), sizeof(int), 1, dataFiles[0]);

     // write initial velocities
      fwrite(&((*xVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
      fwrite(&((*yVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
      fwrite(&((*zVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
      fwrite(&((*zVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);

     // write initial Forces
      fwrite(&((*xFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);
      fwrite(&((*yFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);
      fwrite(&((*zFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);
      fwrite(&((*zFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);
    }
  }


/// END : OUTPUT DATA FILE CREATION ///

/////////////////////////////////////
/////////////////////////////////////
//////////// BEGIN : SIMULATION /////
/////////////////////////////////////
/////////////////////////////////////

  /// COPY DEVICE DATA TO HOST DATA ///
  int done = 0;
  int t = 0, N_fluid_step = 0;
  int totalT = 0;
  int fluidTimeSteps = 1;
  int SEMTimeSteps = 10;
  while (!done) {
    // invoke GPU
    // movement only
    // for(t = 0; t < outputFrequency; t++)
    {
        // sem_invokeGPUKernel(NULL, SEMgrids, X, Y, Z, VX, VY, VZ, FX, FY, FZ, SEMTimeSteps, ClockValue, SlimeDir, totalT);
        // if ( (t%100)==0 ){
            fluid_invokeGPUKernel(NULL, LBgrids, fluidTimeSteps);
            //// TMP, to test fiber and LB coupling
            {
                fluid_initGPUKernel(NULL, LBgrids, 0, hostLBparameters, fIN, fOUT, ux, uy, uz, rho, obstacle);
                // cpu_fiber_LB_coupling(fiber_grids, hostLBparameters, lx, ly, lz, fIN, fOUT, ux, uy, uz, rho, obstacle, dx, dt);
                // printf("exit in runGPUSimulation(), after cpu_fiber_LB_coupling()\n");
                // exit(0);
            }
            //// END:::: TMP, to test fiber and LB coupling
            N_fluid_step++;
        // }
        // printf("At output_frequency = %d\n", t);
    }

    // are we done?
    // totalT += outputFrequency;
    totalT++;
    if (totalT >= timeSteps) done = 1;
       
    // FOR DEBUGGING : WRITE TO SCREEN BETWEEN INVOKES_KERNELS//
#if 0
    for (j = 0; j < numOfCells; ++j) {  // debug for clockvalue
       printf("Cell %d clockValue = %d \n",j,  ClockValue[j]);
       printf("Cell %d SlimeDir = %d \n", j, SlimeDir[j]);
    }
#endif

    if(totalT % outputFrequency == 0)
    { 
        /// COPY DEVICE DATA TO HOST DATA ///
        fluid_initGPUKernel(NULL, LBgrids, 0, hostLBparameters, fIN, fOUT, ux, uy, uz, rho, obstacle);
        sem_copyGPUKernel(NULL, SEMgrids, X, Y, Z, VX, VY, VZ, FX, FY, FZ, outputFrequency, ClockValue, SlimeDir);

        /// BEGIN : DATA OUTPUT  ///

        // output SEM DATA
        printf("Time Step = %d, time = %f\n", totalT, totalT*dt);
        float maxX = 0, maxY = 0, maxZ = 0;
        float minX = (*xGrid)[0][0], minY = (*yGrid)[0][0], minZ = (*zGrid)[0][0];
        //    fwrite(&(numOfCells), sizeof(int), 1, dataFiles[0]);
        // new output file formated (x y z)
        int totAtoms;
        thisFrame = totalT / outputFrequency;
        int nCell, nElem;
        totAtoms = numOfCells*numOfElements[0];
        for (j = 0; j < numOfCells; ++j) {
        //      fwrite(&(numOfElements[j]), sizeof(int), 1, dataFiles[0]);
        //    fprintf(pFile, "%d \n MyxoCells \n", totAtoms);
          for (i = 0; i < numOfElements[j]; ++i) {
        
    	    fwrite(&((*xGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
	    fwrite(&((*xVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
	    fwrite(&((*xFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);

            // fprintf(pFile, "%f ", (*xGrid)[i][j]);
	    fwrite(&((*yGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
	    fwrite(&((*yVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
	    fwrite(&((*yFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);

	    fwrite(&((*zGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
	    fwrite(&((*zVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
	    fwrite(&((*zFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);

	    //fwrite(&((*etGrid)[i][j]), sizeof(int), 1, dataFiles[0]);
            //  We added the extra output...for alignment purposes in the octal dump
	    fwrite(&((*zGrid)[i][j]), sizeof(float), 1, dataFiles[0]);
	    fwrite(&((*zVGrid)[i][j]), sizeof(float), 1, dataFiles[1]);
	    fwrite(&((*zFGrid)[i][j]), sizeof(float), 1, dataFiles[2]);
          }
        }
        totAtoms = i * j;

        // output LB DATA at the center axis of the duct
        /// TMP // FOR DEBUGGING
        {
#if 0
            float fds[19]; 
            fprintf(cent_fp[0],"Time Step = %d\n", N_fluid_step);
            fprintf(cent_fp[1],"Time Step = %d\n", N_fluid_step);
            fprintf(cent_fp[2],"Time Step = %d\n", N_fluid_step);
            /**
            for (i = 0; i < lz ; ++i)
            {
                for(d = 0; d < 19; d++)
                {
                    gridOUT = (void *)fOUT[d];
                    fds[d] = (*gridOUT)[i][1][lx/2];
                }
    
                fprintf(cent_fp[0],"%f, rho = %f\n", (*gridX)[i][1][lx/2], (*gridR)[i][1][lx/2]);
                fprintf(cent_fp[1],"%f\n", (*gridY)[i][1][lx/2]);

                fprintf(cent_fp[2],"%f, rho = %f, fout[%f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f]\n",
                 (*gridZ)[i][1][lx/2], (*gridR)[i][1][lx/2],
                 fds[0], fds[1], fds[2], fds[3], fds[4], fds[5], fds[6], fds[7], fds[8], fds[9], fds[10], fds[11], fds[12], fds[13], 
                 fds[14], fds[15], fds[16], fds[17], fds[18]);
            }
            **/
            for (j = 0; j < ly ; ++j)
            {
                for(d = 0; d < 19; d++)
                {
                    gridOUT = (void *)fOUT[d];
                    fds[d] = (*gridOUT)[1][j][lx/2];
                }

                fprintf(cent_fp[2],"%f, rho = %f, fout[%f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f]\n",
                 (*gridZ)[1][j][lx/2], (*gridR)[1][j][lx/2],
                 fds[0], fds[1], fds[2], fds[3], fds[4], fds[5], fds[6], fds[7], fds[8], fds[9], fds[10], fds[11], fds[12], fds[13], 
                 fds[14], fds[15], fds[16], fds[17], fds[18]);
            }
#endif // if 0
        }
        /// END TMP
        //// Output data to VTK, visualized by paraview
        outputSave(totalT, lx, ly, lz, rho, 1, ux, uy, uz, 1, "Output", "LBMflow");

        for (i = 0; i < lz ; ++i) {
          for (j = 0; j < ly; ++j) {
            for (k = 0; k < lx; ++k) {
            fwrite(&((*gridX)[i][j][k]), sizeof(float), 1, uxFile);
            fwrite(&((*gridY)[i][j][k]), sizeof(float), 1, uyFile);
            fwrite(&((*gridZ)[i][j][k]), sizeof(float), 1, uzFile);
            fwrite(&((*gridR)[i][j][k]), sizeof(float), 1, rhoFile);
            fwrite(&((*gridO)[i][j][k]), sizeof(float), 1, obstFile);
             }
           }
        }
    } //// if(totalT % outputFrequency == 0)
    /// END : DATA OUTPUT  ///

  } //// while (!done){}
  /// END : SIMULTAION ///

  /// BEGIN: RELEASE DATA AND CLOSE FILES ///
  // release GPU
  sem_releaseGPUKernel(NULL, SEMgrids);
  fluid_releaseGPUKernel(NULL, LBgrids);

  // write out final data
  fclose(dataFiles[0]);
  fclose(dataFiles[1]);
  fclose(dataFiles[2]);

  fclose(uxFile);
  fclose(uyFile);
  fclose(uzFile);
  fclose(rhoFile);
  fclose(obstFile);

  fclose(cent_fp[0]);
  fclose(cent_fp[1]);
  fclose(cent_fp[2]);

  /// END: RELEASE DATA AND CLOSE FILES ///
}

int main( int argc, char** argv) 
{
    int dflag = 0; // used for  option argument for device specification
    int gpuDevice;
    int devNum = 0;
    int c;
    // cudaError_t cudareturn;
    int cudareturn;
    //used to handle options passed to program
    while ((c = getopt (argc, argv, "d:")) != -1)
    {
        switch (c)
        {
        case 'd':
            dflag = 1;
            devNum = atoi(optarg);
        break;
        case '?':
            if (isprint (optopt))
                fprintf (stderr, "Unknown option `-%c'.\n", optopt);
            else
                fprintf (stderr,
                    "Unknown option character `\\x%x'.\n",
                    optopt);
            return 1;
        default:
            // abort ();
            printf("GPU device not specified using device 0 ");
       }
    }

    cudareturn = cudaSetDevice( devNum );
    //    printf("cudaSetDevice()=%d\n", cudareturn); 

    //    if (cudareturn == cudaErrorInvalidDevice)
    if (cudareturn == 11 )
    {
       printf("cudaSetDevice returned  11, invalid device number ");
       exit(11);
    }
    else
    {
       cudaGetDevice( &gpuDevice );
      // printf("cudaGetDevice()=%d\n", gpuDevice);
    }
    //printf("Pre Run \n");

    runGPUSimulation();
}

static void outputSave(int t, int nx, int ny, int nz, void *rho, int write_rho,
          void *ux, void *uy, void *uz, int write_vel, char *directory, char *filename)
{
    writeVTK(t, nx, ny, nz, rho, write_rho, ux, uy, uz, write_vel, directory, filename);

    //Calculate Mega Lattice Site Update per second MLSU/s
    // Speed = (nx*ny*nz)*(t-step_now)/((clock() - time_now)/CLOCKS_PER_SEC)/1000000.0;
    // step_now = t;
    // time_now = clock();
    // if (mass == 0) printf("t=%d\tSpeed=%f MLUP/s\n", t, Speed);
    // else printf("t=%d\tSpeed=%f MLUP/s mass=%f\n", t, Speed, mass);
}

static void writeVTK(int t, int nx, int ny, int nz, 
            void *rho, int write_rho, void *ux, void *uy, void *uz, int write_vel, char *directory, char *filename)

{
    int x,y,z,dir;
    char dataFileName[255];
    FILE *dataFile;

    float (*gridX)[nz][ny][nx] = ux;
    float (*gridY)[nz][ny][nx] = uy;
    float (*gridZ)[nz][ny][nx] = uz;
    float (*gridR)[nz][ny][nx] = rho;

#ifdef WIN32
    dir = mkdir(directory);
#else
    dir = mkdir(directory,0777);
#endif

    sprintf(dataFileName,"%s/%s_%07d.vti",directory,filename,t);
    dataFile = fopen(dataFileName,"w");
    fprintf(dataFile, "<?xml version=\"1.0\"?>\n");
    fprintf(dataFile, "<!-- gpuLBMflow ND ACMS -->\n");
    fprintf(dataFile, "<VTKFile type=\"ImageData\" version=\"0.1\" byte_order=\"LittleEndian\">\n");
    fprintf(dataFile, "  <ImageData WholeExtent=\"0 %d 0 %d 0 %d\" Origin=\"0 0 0\" Spacing=\"1 1 1\">\n",nx-1,ny-1,nz-1);
    fprintf(dataFile, "  <Piece Extent=\"0 %d 0 %d 0 %d\">\n",nx-1,ny-1,nz-1);
    fprintf(dataFile, "    <PointData Scalars=\"scalars\">\n");

    //write density
    if (write_rho != 0)
    {
        fprintf(dataFile, "      <DataArray type=\"Float32\" Name=\"Density\" NumberOfComponents=\"1\" format=\"ascii\">\n");
        for (z=0; z<nz; z++)
        {
            for (y=0; y<ny; y++)
            {
                for (x=0; x<nx; x++)
                {
                    fprintf(dataFile,"%.4e ", (*gridR)[z][y][x]);
                }
                fprintf(dataFile, "\n");
            }
        }
        fprintf(dataFile, "      </DataArray>\n");
    }


    //fprintf(dataFile, "    <PointData Vectors=\"Velocity\">\n");
    //write velocity
    if (write_vel != 0)
    {
        fprintf(dataFile, "      <DataArray type=\"Float32\" Name=\"Velocity\" NumberOfComponents=\"3\" format=\"ascii\">\n");
        for (z=0; z<nz; z++)
        {
            for (y=0; y<ny; y++)
            {
                for (x=0; x<nx; x++)
                {
                    fprintf(dataFile,"%.4e ", (*gridX)[z][y][x]);
                    fprintf(dataFile,"%.4e ", (*gridY)[z][y][x]);
                    fprintf(dataFile,"%.4e ", (*gridZ)[z][y][x]);
                }
                fprintf(dataFile, "\n");
            }
        }
        fprintf(dataFile, "      </DataArray>\n");
    }
    //fprintf(dataFile, "    </PointData>\n");

    fprintf(dataFile, "    </PointData>\n");

    fprintf(dataFile, "    <CellData>\n");
    fprintf(dataFile, "    </CellData>\n");
    fprintf(dataFile, "  </Piece>\n");
    fprintf(dataFile, "  </ImageData>\n");

    fprintf(dataFile, "</VTKFile>\n");
    fclose(dataFile);
}
