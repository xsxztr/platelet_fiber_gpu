#!/bin/bash
./gpuSEM_LB -d 1
