#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include "GPUDefines.h"
#include "network.h"


void *init_fibrin_network(float dt)
{
        // char FibrinName[] = "Input/KRM2.txt";
        char    FibrinName[] = "Input/HemoThickInputCor.txt";
        FILE    *FibrinIn;
        int     i, j, k, n_link_sz, total_N_fiber = 0;
        double  f_len;

        network myNetwork;

        // ~~~~~~ READ and STORE INPUT DATA ~~~~~~~~~~~~~~~~//
        string line;
        ifstream Input;

        // FibrinIn = fopen(FibrinName, "r");
        // if(NULL == FibrinIn)
        // {
        //     printf("ERROR: init_fibrin_network(), can not open %s, exit\n",  FibrinName);
        //     exit(0);
        // }

        Input.open(FibrinName); //SampleC.txt, KRM2, HemoThickInputCor
        // check
        if(!Input.is_open())
        {
            std::cout << "init_fibrin_network() cannot open file: " << FibrinName  << std::endl;
            exit(0);
        }

        // Temporary storage vector to read data
        vector <int> NConnect;
        vector <int> nodeNumber;

        NConnect.clear();

        myNetwork.linkr.clear();
        myNetwork.fibersize.clear();
        myNetwork.branchp.clear();

        // Read new format file with thickness
        while(getline(Input,line)){

                vector <double> dat; // reading first line
                dat.clear();//clear
                vector < int > Connect; //linking, connection information
                vector < double > Fsize; // fibrin information, thickness, size

                Connect.clear();
                Fsize.clear();

                double value;

                istringstream iss(line); // line in the file

                //read data
                while(iss >> value)
                {
                //cout << value << endl;
                    dat.push_back(value);   // store the whole line in the value, dat
                }

                //get size of data
                const unsigned int dasz = dat.size();

                //record node number
                nodeNumber.push_back(dat[0]);  // first component of the line

                // stores coordinates of each node
                const double aa = 1.0;
                myNetwork.putIntoVec(dat[1]/aa,dat[2]/aa,dat[3]/aa);

                // stores number of connections
                NConnect.push_back(dat[4]);

                // stores list of connecting node
                Connect.push_back(dat[0]);

                for(int jj = 5; jj < dat[4]+5; jj++)
                { // 5 is the first of the connecting node, th column in the file
                  // exclude connecting node if it is the same as node number
                    if( dat[jj] != dat[0]) Connect.push_back(dat[jj]);
                }

                // store list of connections
                myNetwork.linkr.push_back(Connect);

                // stores fiber thickness for all connections of a particular node
                //Fsize.push_back(dat[0]);
                for(int kk = dat[4] + 5; kk < dasz;kk++)
                { // dat[4] is the number ofconnections, 5 is the first column of connected node
                    const unsigned int te = kk - dat[4];// uniportant..trying
                     //cout << dat[te] << " " << dat[0] <<  " " << kk << endl;
                    if( dat[te]  != dat[0])
                    { //uniportant
                        Fsize.push_back(dat[kk]/1.0); //this is working, elementary thickness info
                    }
                }
                //store fiber thickness
                myNetwork.fibersize.push_back(Fsize); // container of thickness, vector of values
        }

        Input.close();
        // ~~~~~~ SET PARAMETERS and RECORD INITIAL STATE OF NETWORK ~~~~~~~~~~~~~~~~//
        // store coordinates of node into 1-D vector
        myNetwork.storeCoords(); // stores, #node, x,y,z; need to read about vector class
        
        // get network statistics: average thickness and number of branching points
        myNetwork.getstat();
        
        /// INIT memory of fibrin network structure for GPUs. For Input/KRM2.txt
        const unsigned int sz = myNetwork.node.size();
                           //// Network Node size = 21333 = branch_sz * 3
        const int          branch_sz = myNetwork.branchp.size();
                           /// Network branch point size = 7111
        int OLink, NLink, linksz;
        OLink = myNetwork.numberoffibers(0);
        linksz = myNetwork.linkr.size();
        cout <<"Network Node size = "<< sz <<" Network branch point size = " << branch_sz <<
                          " Number of fibers = " << OLink <<" linker size = " << linksz  << endl;
  
        //myNetwork.getBNodes();
        myNetwork.newvel.clear();
        myNetwork.newvel.resize(sz,0);
     
        cout << myNetwork.getBCs(0,0)<< " " << myNetwork.getBCs(1,0) << endl; //three coordinates x,y,z bc microns
        cout << myNetwork.getBCs(0,1)<< " " << myNetwork.getBCs(1,1) << endl;
        cout << myNetwork.getBCs(0,2)<< " " << myNetwork.getBCs(1,2) << endl;
     
        const double tzs =  myNetwork.getBCs(0,2); //min z
        const double tze = myNetwork.getBCs(1,2);// max z
        const double dz =tze - tzs;//thickness of network in z
        const double Stzs = tzs + 0.1*dz;
        const double Stze = tze - 0.1*dz;
     
        const double txs = myNetwork.getBCs(0,0); //min x
        const double txe = myNetwork.getBCs(1,0); //max x
        const double dx = txe - txs;
        const double Stx = txe - 0.1*dx;
            
        const double tys = myNetwork.getBCs(0,1); //min y
        const double tye = myNetwork.getBCs(1,1); //max y
        const double dy = tye - tys;
            
        const double Stxs = txs + 0.1*dx; // added by Oleg,9.17.2010, for streching in x-direction
        const double Stxe = txe - 0.1*dx;
        const double Stys = tys + 0.1*dy; // added by Oleg,9.17.2010, for streching in y-direction
        const double Stye = tye - 0.1*dy;

        // viscosity of blood 0.04 poise = 0.004 N second/meter squared
        // viscosity of plasma 0.015 poise = 0.0015 N second/meter squared
        double myGamma = 4*1e3; //nano N micro S/micro sq

        //const double radius = myNetwork.fibersize[0][1]/2.0;
        const double radius = 23*1e-3;

        const double mass = 3.14*(radius*radius)*10; // pico gram, dens = 1000 kg /m^3
        //Stokes Equation
        const double gamma = 6*3.14*myGamma*radius/mass;

        // loop through nodes 
        /***
        for(i = 0; i < branch_sz; i++)
        {
            cout <<"branch_pt_crds[" << i <<"] = [" <<  myNetwork.branchp[i].x  << "," << 
                   myNetwork.branchp[i].y <<","<< myNetwork.branchp[i].z << "]; from node[" 
                      << myNetwork.node[3*i] <<"," << myNetwork.node[3*i+1] <<"," <<  myNetwork.node[3*i+2] <<"]" << endl;
        }
        ***/

        // 1 pixel = 0.14 micrometer,
        //const double radius = thickness*0.14/1e6/2;
        // const double radius = thickness/2;

        // loop through links, fiber diameter
        // reference: network::getSpringForce();
        for(i = 0; i < linksz; i++)
        {
            int oindex = myNetwork.linkr[i][0]; 
            n_link_sz = myNetwork.linkr[i].size(); // = actual # of fibers + 1

            // cout<<"Number of links = "<< n_link_sz << endl;

            for(int j = 1; j  < n_link_sz; j++) 
            {
                double thickness = myNetwork.fibersize[i][j-1];
                k = myNetwork.linkr[i][j];
                if(k > oindex)
                {
                    double rlx = (myNetwork.node[3*k] - myNetwork.node[3*oindex]);
                    double rly = (myNetwork.node[3*k+1] - myNetwork.node[3*oindex+1]);
                    double rlz = (myNetwork.node[3*k+2] - myNetwork.node[3*oindex+2]);
                    f_len = sqrt(rlx*rlx + rly*rly + rlz*rlz);
                    total_N_fiber++;

                    printf("fiber[%d], len = %f, thinkness = %f\n", total_N_fiber, f_len, thickness);
                }
            }
            // exit(0);
        }


        void *Fibergrids = fiber_allocGPUKernel(NULL,  branch_sz, total_N_fiber, dt);

        cout <<"Test code, exit in init_fibrin_network()" << endl;
        exit(0);
        
        return Fibergrids;
} 
