/*
 GPUDefines.h
 
 Definitions for GPU code.
 
 Copyright (C) 2010 Scott Christley
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met: 1. Redistributions of source code must retain the above
 copyright notice, this list of conditions and the following
 disclaimer.  2. Redistributions in binary form must reproduce the
 above copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided with
 the distribution.  3. The name of the author may not be used to
 endorse or promote products derived from this software without
 specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
#if !defined(_GPUDefines_H)
#define _GPUDefines_H

typedef struct _RK2grids {
  int speciesCount;
  void **speciesGrid;
  void **speciesF1;
  void **speciesF2;
  void **speciesDiff;
} RK2grids;

typedef struct _RModelRK2_GPUptrs {
  int numOfODEs;
  int numParams;
  float dt;
  float EPS;
  int *localEpsilonCheck;
  int *epsilonCheck;
  int speciesCount;
  float *speciesData;
  float *speciesF1;
  float *speciesF2;
  size_t speciesPitch;
  float *parameters;
  size_t paramPitch;
} RModelRK2_GPUptrs;

typedef struct _ModelGPUData {
  void *data;
  float *parameters;
  int numModels;
  int numParams;
  void *gpuPtrs;
  void *gpuFunctions;
} ModelGPUData;

// typedef for GPU functions

// ReactionModel, static structure
typedef	void* (allocRModelGPUFunction)(void*, int, int, int, float, float);
typedef void (initRModelGPUFunction)(void*, void*, float*, float*);
typedef void (invokeRModelGPUFunction)(void*, void*, float*, int);
typedef void (releaseRModelGPUFunction)(void*, void*);

typedef struct _RModelGPUFunctions {
    allocRModelGPUFunction *allocGPUKernel;
    initRModelGPUFunction *initGPUKernel;
    invokeRModelGPUFunction *invokeGPUKernel;
    releaseRModelGPUFunction *releaseGPUKernel;
} RModelGPUFunctions;

// ReactionModel, dynamic structure
typedef	void* (allocRModelDynamicGPUFunction)(void*, int, int, int, float, float);
typedef void (initRModelDynamicGPUFunction)(void*, void*, float*, float*, float*, float*, float*, float*, float*, int*, int*, int*, int*);
typedef void (invokeRModelDynamicGPUFunction)(void*, void*, float*, int);
typedef void (releaseRModelDynamicGPUFunction)(void*, void*);

typedef struct _RModelDynamicGPUFunctions {
  allocRModelDynamicGPUFunction *allocGPUKernel;
  initRModelDynamicGPUFunction *initGPUKernel;
  invokeRModelDynamicGPUFunction *invokeGPUKernel;
  releaseRModelDynamicGPUFunction *releaseGPUKernel;
} RModelDynamicGPUFunctions;

// ReactionDiffusionModel
typedef	void* (allocRDModelGPUFunction)(void*, float, float, float*, int, int);
typedef void (initRDModelGPUFunction)(void*, void*, float*, RK2grids*);
typedef void (invokeRDModelGPUFunction)(void*, void*, RK2grids*, int);
typedef void (releaseRDModelGPUFunction)(void*, void*);

typedef struct _RK2functions {
    allocRDModelGPUFunction *allocGPUKernel;
    initRDModelGPUFunction *initGPUKernel;
    invokeRDModelGPUFunction *invokeGPUKernel;
    releaseRDModelGPUFunction *releaseGPUKernel;
} RK2functions;

// Hill function
// General form
// f(X) = a + (b - a) / (1 + (X / c)^h)
#ifndef HILL
#define HILL(X, A, B, C, H) ((A) + ((B) - (A)) / (1 + pow((X) / (C), H)))
#endif

#define     sqr(x)       ((x)*(x))
#define     cub(x)       ((x)*(x)*(x))
#define     quar(x)      ((x)*(x)*(x)*(x))

////////// global functions
///// gpuSEM_LB.c /////
///// semLB.cu /////
///// C function callable by C++ code.
#ifdef __cplusplus
extern "C" { 
#endif // #ifdef __cplusplus
extern void  *fiber_allocGPUKernel(void *model, int maxNodes, int maxLinks, float dt);
#ifdef __cplusplus
}
#endif // #ifdef __cplusplus

///// fiber.cpp /////
//// C++ function that is callable by C code.
#ifdef __cplusplus
extern "C" { 
#endif // #ifdef __cplusplus
void  *init_fibrin_network(float dt); 
// void  *fiber_allocGPUKernel(void *model, int maxNodes, int maxLinks, float dt);
#ifdef __cplusplus
}
#endif // #ifdef __cplusplus
///// END:  fiber.cpp /////


#endif /// #if !defined(_GPUDefines_H)
